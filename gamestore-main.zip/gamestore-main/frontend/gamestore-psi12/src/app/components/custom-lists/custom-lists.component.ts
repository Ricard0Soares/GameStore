import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-lists',
  templateUrl: './custom-lists.component.html',
  styleUrls: ['./custom-lists.component.css']
})
export class CustomListsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
