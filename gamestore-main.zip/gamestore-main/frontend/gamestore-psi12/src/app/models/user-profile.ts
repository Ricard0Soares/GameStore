export interface UserProfile {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    bio: string;
    profilePicture: string;
  }
  