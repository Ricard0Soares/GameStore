export const environment = {
    api:'http://appserver.alunos.di.fc.ul.pt:3012'
};
